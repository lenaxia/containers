# Kubernetes tutorial

The Kubernetes tutorial has moved to
https://github.com/cue-labs/cue-by-example/tree/main/003_kubernetes_tutorial.
