# CUE Tour

The CUE Tour has now moved to https://cuelang.org/docs/tour/ with the source
available under https://github.com/cue-lang/cuelang.org/tree/master/content/docs/tour.
